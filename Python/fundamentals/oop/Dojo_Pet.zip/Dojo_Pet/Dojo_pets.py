import ninja
import pet_class

ninja1 = ninja.Ninja('Matt', 'Rice', 'biscuits', 'chicken and rice', pet_class.fluffy)

ninja1.feed().walk().bathe()